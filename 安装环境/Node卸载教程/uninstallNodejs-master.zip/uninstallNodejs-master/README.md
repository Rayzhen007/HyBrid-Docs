a uninstall Nodejs script
